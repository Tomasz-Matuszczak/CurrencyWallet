﻿namespace CurrencyWallet.Models
{
    public class WalletTransaction
    {
        public string CurrencyCode { get; set; }
        public decimal Amount { get; set; }
    }
}
