﻿namespace CurrencyWallet.Models
{
    public class NbpResponse
    {
        public required List<CurrencyRate> Rates { get; set; }
    }
}