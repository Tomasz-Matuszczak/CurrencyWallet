﻿namespace CurrencyWallet.Models
{
    public class UserModel
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
